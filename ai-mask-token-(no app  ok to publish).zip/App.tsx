
import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Cpu, 
  Lock, 
  Globe, 
  BarChart3, 
  ExternalLink, 
  Copy, 
  CheckCircle2, 
  Twitter, 
  Send, 
  Mail,
  Zap,
  Layers,
  Award,
  ArrowRight
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

// --- Utility Components ---

// Fix: Made children optional to resolve TS errors regarding missing children property in type validation
const Section = ({ id, children, className = "" }: { id?: string, children?: React.ReactNode, className?: string }) => (
  <section id={id} className={`py-20 px-6 md:px-12 lg:px-24 ${className}`}>
    <div className="max-w-7xl mx-auto">
      {children}
    </div>
  </section>
);

// Fix: Made children optional to resolve TS errors regarding missing children property in type validation
const GlowingButton = ({ 
  children, 
  href, 
  variant = 'primary', 
  onClick 
}: { 
  children?: React.ReactNode, 
  href?: string, 
  variant?: 'primary' | 'secondary',
  onClick?: () => void
}) => {
  const baseClasses = "px-8 py-4 rounded-full font-bold transition-all duration-300 flex items-center justify-center gap-2 relative overflow-hidden group";
  const variants = {
    primary: "bg-gradient-to-r from-cyan-500 to-purple-600 text-white hover:scale-105 neon-glow",
    secondary: "glass text-slate-100 hover:bg-slate-800/50"
  };

  const content = (
    <>
      <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
      {children}
    </>
  );

  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={`${baseClasses} ${variants[variant]}`}>
        {content}
      </a>
    );
  }

  return (
    <button onClick={onClick} className={`${baseClasses} ${variants[variant]}`}>
      {content}
    </button>
  );
};

// --- Main Components ---

const BackgroundEffects = () => (
  <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
    {/* Floating Particles Simulation */}
    <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] animate-pulse"></div>
    <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] animate-pulse delay-1000"></div>
    
    {/* Animated Circuit Lines Grid */}
    <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#22d3ee 0.5px, transparent 0.5px)', backgroundSize: '24px 24px' }}></div>
  </div>
);

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4 ${scrolled ? 'glass py-3' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2 group cursor-pointer">
          <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-lg flex items-center justify-center neon-glow group-hover:rotate-12 transition-transform">
            <Shield className="text-white w-6 h-6" />
          </div>
          <span className="text-xl font-extrabold tracking-tighter text-white">AI MASK</span>
        </div>
        
        <div className="flex items-center gap-8 text-sm font-semibold text-slate-300 uppercase tracking-widest">
          <a href="#about" className="hover:text-cyan-400 transition-colors">About</a>
          <a href="#ecosystem" className="hover:text-cyan-400 transition-colors">Ecosystem</a>
          <a href="#tokenomics" className="hover:text-cyan-400 transition-colors">Tokenomics</a>
          <a href="#roadmap" className="hover:text-cyan-400 transition-colors">Roadmap</a>
        </div>
      </div>
    </nav>
  );
};

const Hero = () => {
  const contract = "0x81782141A12cE774773Ec8198c9218aC51654128";
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(contract);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Section className="pt-40 pb-32 text-center">
      <div className="flex flex-col items-center">
        {/* Animated Logo */}
        <div className="relative mb-8">
          <div className="absolute inset-0 bg-cyan-400 blur-2xl opacity-20 animate-pulse"></div>
          <div className="w-32 h-32 md:w-40 md:h-40 glass rounded-[2.5rem] flex items-center justify-center animate-pulse-glow border-2 border-cyan-500/50">
            <div className="relative">
              <Shield className="w-16 h-16 md:w-20 md:h-20 text-cyan-400" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-purple-500 rounded-full blur-sm"></div>
            </div>
          </div>
        </div>

        <h1 className="text-5xl md:text-7xl lg:text-8xl font-black mb-6 tracking-tight leading-tight">
          AI MASK TOKEN <br />
          <span className="text-gradient">THE FUTURE OF SECURITY</span>
        </h1>
        
        <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed font-light">
          A next-generation Web3 ecosystem merging neural intelligence with decentralized protection to ensure total privacy in the digital age.
        </p>

        {/* Contract Info Box */}
        <div className="glass px-6 py-4 rounded-2xl mb-12 max-w-lg mx-auto w-full flex flex-col items-center gap-4">
          <div className="grid grid-cols-2 gap-8 w-full border-b border-white/5 pb-4">
            <div>
              <p className="text-xs text-slate-500 uppercase font-bold tracking-widest mb-1">Total Supply</p>
              <p className="text-xl font-bold text-white">5,000,000,000</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 uppercase font-bold tracking-widest mb-1">Network</p>
              <p className="text-xl font-bold text-cyan-400">BSC (BEP-20)</p>
            </div>
          </div>
          <div className="w-full">
            <p className="text-xs text-slate-500 uppercase font-bold tracking-widest mb-2">Contract Address</p>
            <div className="bg-slate-900/50 rounded-lg p-3 flex items-center justify-between gap-3 border border-white/5">
              <code className="text-[10px] md:text-sm text-slate-300 break-all">{contract}</code>
              <button onClick={copyToClipboard} className="text-slate-400 hover:text-white transition-colors">
                {copied ? <CheckCircle2 className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <GlowingButton href={`https://pancakeswap.finance/swap?outputCurrency=${contract}`}>
            Buy on PancakeSwap <Zap className="w-4 h-4" />
          </GlowingButton>
          <GlowingButton variant="secondary" href={`https://bscscan.com/token/${contract}`}>
            View Contract <ExternalLink className="w-4 h-4" />
          </GlowingButton>
        </div>
      </div>
    </Section>
  );
};

const About = () => (
  <Section id="about" className="bg-slate-950/50">
    <div className="grid md:grid-cols-2 gap-16 items-center">
      <div className="relative">
        <div className="absolute -inset-4 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-2xl blur-2xl opacity-10"></div>
        <div className="relative glass p-10 rounded-2xl border-white/10 space-y-6">
          <h2 className="text-4xl font-bold mb-4">Redefining <span className="text-cyan-400">Digital Anonymity</span></h2>
          <p className="text-slate-400 leading-loose">
            In an era where every transaction and interaction is tracked, AI Mask (AMT) stands as the ultimate shield. We combine sophisticated AI algorithms with blockchain transparency to create a "Mask" for your digital identity.
          </p>
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-cyan-500/10 flex-shrink-0 flex items-center justify-center">
              <Lock className="text-cyan-400" />
            </div>
            <div>
              <h4 className="font-bold text-white text-lg">Absolute Protection</h4>
              <p className="text-sm text-slate-400">Encrypted transmission layers that hide origin points while maintaining speed.</p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex-shrink-0 flex items-center justify-center">
              <Cpu className="text-purple-400" />
            </div>
            <div>
              <h4 className="font-bold text-white text-lg">AI-Driven Auditing</h4>
              <p className="text-sm text-slate-400">Autonomous systems that detect and deflect cyber threats in real-time.</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="space-y-8">
        <span className="px-4 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-bold tracking-widest uppercase border border-cyan-500/30">
          The Mission
        </span>
        <h3 className="text-5xl font-black leading-tight">Privacy is Not a Crime. It's a <span className="text-gradient">Fundamental Right.</span></h3>
        <p className="text-slate-400 text-lg">
          AMT isn't just a token; it's a movement toward a secure, decentralized web where users control their own data footprint. Using mask symbolism, we represent the ability to remain unknown while being fully verified.
        </p>
        <button className="flex items-center gap-2 text-cyan-400 font-bold hover:gap-4 transition-all">
          Read Whitepaper <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  </Section>
);

const Ecosystem = () => {
  const cards = [
    {
      icon: <Layers className="w-8 h-8 text-cyan-400" />,
      title: "AMT Utility",
      desc: "Use AMT to access premium AI security tools and privacy protocols within our dApp suite."
    },
    {
      icon: <Award className="w-8 h-8 text-purple-400" />,
      title: "Community Rewards",
      desc: "Holders earn passive reflections and exclusive access to early-stage security project launches."
    },
    {
      icon: <Cpu className="w-8 h-8 text-cyan-400" />,
      title: "AI Security Vision",
      desc: "An evolving neural network that learns from global threats to protect every AMT holder's wallet."
    },
    {
      icon: <BarChart3 className="w-8 h-8 text-purple-400" />,
      title: "Dynamic Staking",
      desc: "Flexible staking pools with tiered APY models designed for long-term ecosystem stability."
    }
  ];

  return (
    <Section id="ecosystem">
      <div className="text-center mb-16">
        <h2 className="text-5xl font-black mb-4 uppercase tracking-tighter">Powering the <span className="text-gradient">Ecosystem</span></h2>
        <p className="text-slate-400 max-w-2xl mx-auto">Multiple layers of value, one unified token. Explore the pillars of the AI Mask architecture.</p>
      </div>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, idx) => (
          <div key={idx} className="glass p-8 rounded-2xl hover:border-cyan-500/50 transition-all hover:-translate-y-2 group">
            <div className="mb-6 p-4 rounded-xl bg-slate-900 group-hover:bg-cyan-500/10 transition-colors w-fit">
              {card.icon}
            </div>
            <h4 className="text-xl font-bold mb-3 text-white">{card.title}</h4>
            <p className="text-slate-400 text-sm leading-relaxed">{card.desc}</p>
          </div>
        ))}
      </div>
    </Section>
  );
};

const Tokenomics = () => {
  const data = [
    { name: 'Liquidity', value: 40, color: '#22d3ee' },
    { name: 'Community', value: 30, color: '#818cf8' },
    { name: 'Development', value: 15, color: '#a855f7' },
    { name: 'Marketing', value: 10, color: '#e879f9' },
    { name: 'Staking', value: 5, color: '#ec4899' },
  ];

  return (
    <Section id="tokenomics" className="bg-slate-950/50 overflow-hidden relative">
      <div className="absolute -right-20 top-0 w-96 h-96 bg-purple-500/5 blur-[120px]"></div>
      
      <div className="text-center mb-16">
        <h2 className="text-5xl font-black mb-4 uppercase tracking-tighter">Robust <span className="text-gradient">Tokenomics</span></h2>
        <p className="text-slate-400 max-w-2xl mx-auto">A balanced distribution model focused on long-term growth and holder incentivization.</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="h-[400px] w-full relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={80}
                outerRadius={140}
                paddingAngle={5}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                itemStyle={{ color: '#fff' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-3xl font-black text-white">5 BILLION</span>
            <span className="text-xs text-slate-500 font-bold tracking-[0.2em] uppercase">Total Supply</span>
          </div>
        </div>

        <div className="space-y-4">
          {data.map((item, idx) => (
            <div key={idx} className="glass p-5 rounded-2xl flex items-center justify-between group transition-all hover:bg-white/5">
              <div className="flex items-center gap-4">
                <div className="w-3 h-10 rounded-full" style={{ backgroundColor: item.color }}></div>
                <div>
                  <p className="text-white font-bold">{item.name}</p>
                  <p className="text-xs text-slate-500 uppercase font-semibold">Allocation</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-black text-white">{item.value}%</p>
                <p className="text-xs text-slate-500">{((item.value / 100) * 5000000000).toLocaleString()} AMT</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
};

const Roadmap = () => {
  const steps = [
    {
      period: "Q1 - Genesis",
      title: "The Awakening",
      items: ["Token Launch on BSC", "Community Hub (TG/X)", "Smart Contract Audit", "PancakeSwap Listing"],
      completed: true
    },
    {
      period: "Q2 - Integration",
      title: "Neural Network",
      items: ["AI Security Beta Deployment", "Privacy Protocol Whitepaper v2", "Strategic Partnerships", "Major CEX Listing Prep"],
      completed: false
    },
    {
      period: "Q3 - Expansion",
      title: "The Mask Protocol",
      items: ["Masking dApp Launch", "AMT Staking Dashboard", "Cross-chain Bridges (Eth/Sol)", "Tier 1 Exchange Listing"],
      completed: false
    },
    {
      period: "Q4 - Autonomy",
      title: "DAO Governance",
      items: ["Decentralized Governance Launch", "AI Threat Intelligence API", "Global Marketing Campaign", "AMT 2.0 Ecosystem Upgrade"],
      completed: false
    }
  ];

  return (
    <Section id="roadmap">
      <div className="text-center mb-16">
        <h2 className="text-5xl font-black mb-4 uppercase tracking-tighter">Project <span className="text-gradient">Timeline</span></h2>
        <p className="text-slate-400 max-w-2xl mx-auto">Our path towards absolute digital privacy and intelligence.</p>
      </div>

      <div className="relative">
        {/* Central vertical line */}
        <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-cyan-400 via-purple-500 to-transparent hidden md:block"></div>

        <div className="space-y-12">
          {steps.map((step, idx) => (
            <div key={idx} className={`flex flex-col md:flex-row items-center gap-8 ${idx % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
              <div className={`md:w-1/2 flex ${idx % 2 === 0 ? 'md:justify-end' : 'md:justify-start'}`}>
                <div className="glass p-8 rounded-2xl w-full max-w-md relative group hover:border-cyan-500/50 transition-all">
                  <span className={`text-xs font-bold tracking-widest uppercase mb-2 block ${step.completed ? 'text-green-400' : 'text-cyan-400'}`}>
                    {step.period} {step.completed && "• COMPLETED"}
                  </span>
                  <h4 className="text-2xl font-black mb-4 text-white uppercase">{step.title}</h4>
                  <ul className="space-y-3">
                    {step.items.map((item, i) => (
                      <li key={i} className="flex items-center gap-3 text-slate-400 text-sm">
                        <div className={`w-1.5 h-1.5 rounded-full ${step.completed ? 'bg-green-500' : 'bg-cyan-500'}`}></div>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              {/* Center point */}
              <div className="w-10 h-10 rounded-full bg-slate-950 border-2 border-cyan-500 neon-glow relative z-10 hidden md:flex items-center justify-center shrink-0">
                <div className={`w-3 h-3 rounded-full ${step.completed ? 'bg-green-400 animate-ping' : 'bg-cyan-400 animate-pulse'}`}></div>
              </div>

              <div className="md:w-1/2"></div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
};

const Footer = () => (
  <footer className="bg-slate-950 border-t border-white/5 pt-20 pb-10 px-6 md:px-12 lg:px-24">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-4 gap-12 mb-16">
        <div className="lg:col-span-1 space-y-6">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-lg flex items-center justify-center">
              <Shield className="text-white w-6 h-6" />
            </div>
            <span className="text-xl font-extrabold tracking-tighter text-white">AI MASK</span>
          </div>
          <p className="text-slate-500 text-sm leading-relaxed">
            The next generation of privacy-focused blockchain technology powered by advanced neural intelligence. Join the security revolution.
          </p>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 glass rounded-lg flex items-center justify-center hover:bg-cyan-500/10 hover:text-cyan-400 transition-all">
              <Twitter className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 glass rounded-lg flex items-center justify-center hover:bg-cyan-500/10 hover:text-cyan-400 transition-all">
              <Send className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 glass rounded-lg flex items-center justify-center hover:bg-cyan-500/10 hover:text-cyan-400 transition-all">
              <Mail className="w-5 h-5" />
            </a>
          </div>
        </div>

        <div>
          <h5 className="font-bold text-white mb-6 uppercase tracking-widest text-xs">Resources</h5>
          <ul className="space-y-4 text-sm text-slate-500">
            <li><a href="#" className="hover:text-white transition-colors">Whitepaper</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Documentation</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Github Repo</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Branding Kit</a></li>
          </ul>
        </div>

        <div>
          <h5 className="font-bold text-white mb-6 uppercase tracking-widest text-xs">Community</h5>
          <ul className="space-y-4 text-sm text-slate-500">
            <li><a href="#" className="hover:text-white transition-colors">Telegram Chat</a></li>
            <li><a href="#" className="hover:text-white transition-colors">X (Twitter) Feed</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Discord Server</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Medium Blog</a></li>
          </ul>
        </div>

        <div className="glass p-6 rounded-2xl border-cyan-500/20">
          <h5 className="font-bold text-white mb-4 uppercase tracking-widest text-xs">Stay Informed</h5>
          <p className="text-xs text-slate-500 mb-4">Get the latest updates on AI security and AMT development.</p>
          <div className="flex gap-2">
            <input 
              type="email" 
              placeholder="Email address" 
              className="bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 w-full"
            />
            <button className="bg-cyan-500 hover:bg-cyan-400 text-slate-900 font-bold p-2 rounded-lg transition-colors">
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="pt-10 border-t border-white/5 text-center space-y-4">
        <p className="text-[10px] text-slate-600 uppercase tracking-[0.3em]">
          &copy; 2025 AI MASK TOKEN (AMT). ALL RIGHTS RESERVED.
        </p>
        <div className="max-w-2xl mx-auto bg-slate-900/50 p-4 rounded-xl border border-red-500/10">
          <p className="text-[10px] text-slate-500 leading-relaxed">
            DISCLAIMER: AMT IS A UTILITY TOKEN. TRADING CRYPTOCURRENCIES INVOLVES SIGNIFICANT RISK AND CAN RESULT IN THE LOSS OF INVESTED CAPITAL. THIS PROJECT IS NOT FINANCIAL ADVICE. ALWAYS CONDUCT YOUR OWN RESEARCH (DYOR) BEFORE INVESTING IN ANY DIGITAL ASSET.
          </p>
        </div>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <div className="relative min-h-screen">
      <BackgroundEffects />
      <Navbar />
      <main>
        <Hero />
        <About />
        <Ecosystem />
        <Tokenomics />
        <Roadmap />
      </main>
      <Footer />
    </div>
  );
}
